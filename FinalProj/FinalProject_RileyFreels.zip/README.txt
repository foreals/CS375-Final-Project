README.txt

Riley Freels

1. compile the programs with 'make'
2. run referee program with ./referee
3. run player programs with ./player

Player 1 will connect and be prompted to enter a choice first.
Then Player 2 will follow.

Both players will alternate until a zero '0' is entered.

Referee will run for eternity. Send the interrupt signal ^C to kill the program.

Thank you! Have a great winter break!
